 for run the script by python
just go in the address of the script then run this commend:
python spent_app.py
=================================================================
