for run the application:
1-run cmd in the address of the application 
2-run this commend: .\spent_app.exe
3-now just use the application and enjoy it (: 